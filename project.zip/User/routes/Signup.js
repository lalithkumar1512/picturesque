function person(firstname,lastname,email,gender,phone,username,bio){
    this.firstname = firstname;
    this.laststname = lastname;
    this.email= email;
    this.gender = gender ;
    this.phone = phone;
}
