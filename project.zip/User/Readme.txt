README
-------------
Prerequisite: Install Node,express,mongodb

For database,install the mongodb resources using below links
https://www.mongodb.com/try/download/community
https://www.mongodb.com/try/download/compass

extract the community file to .vscode folder.

npm init

Please install all the required packages.
npm install nodemon
npm install body-parser
npm install mongodb
etc

Run the application:
nodemon server.js

Open the following link
http://localhost:5003/


github repo link:
